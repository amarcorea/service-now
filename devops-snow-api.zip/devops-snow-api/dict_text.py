rls_text = {
    "1": "(New)",
    "2": "(Certification)",
    "14": "(Waiting Accept)",
    "15": "Pre-Production",
    "5": "(Test)",
    "6": "(Evaluation-Asses)",
    "8": "(Scheduled)",
    "9": "(Implementation)",
    "10": "(Revision)",
    "11": "(Closed)",
    "16": "(Authorize)",
    "-5": "Pending",
    "13": "Cancelled"
}

tsk_text = {
    "-5": "Pending",
    "1": "Open",
    "3": "Closed Complete",
    "7": "Closed Skipped"
}
